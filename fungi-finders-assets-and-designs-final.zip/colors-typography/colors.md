# Colors

accent-dark: #23412F;
accent-light: #659477;
accent: #3B8256;
brown-1: #423D3C;
brown-2: #383231;
brown-3: #2D2726;
brown-4: #292424;
brown-5: #221E1E;
burnt-orange: #875C36;
gray: #CBC9C9;
primary-light: #F7B687;
primary: #F59C5C;
red: #7E3E3F;
teal: #377E86;
white: #FFFFFF