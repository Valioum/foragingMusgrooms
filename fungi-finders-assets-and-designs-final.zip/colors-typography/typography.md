# Font sizes

## Desktop

title-large: 120px;
title-small: 80px;
section-heading: 48px;
heading: 32px;
body-large: 24px;
body-medium: 20px;
body-regular: 16px;
body-small: 14px;

## Mobile

title: 60px;
section-heading: 36px;
heading: 24px;
body-large: 20px;
body-medium: 18px;
body-regular: 16px;
body-small: 14px;
